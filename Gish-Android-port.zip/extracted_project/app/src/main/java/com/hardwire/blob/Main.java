package com.hardwire.blob;

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import com.gish.remaster.game.ad; // Main game canvas/MIDlet class

public class Main extends MIDlet {
    private static Main instance;
    private ad gameCanvas;

    public Main() {
        instance = this;
    }

    public static Main getInstance() {
        return instance;
    }

    @Override
    public void startApp() {
        if (gameCanvas == null) {
            gameCanvas = new ad();
        }
        Display.getDisplay(this).setCurrent(gameCanvas);
    }

    @Override
    public void pauseApp() {
        if (gameCanvas != null) {
            // pause game loop
        }
    }

    @Override
    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
}
