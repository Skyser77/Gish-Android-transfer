package com.gish.remaster.game;

/*
 * Decompiled with CFR 0.152.
 */
public class ae {
    public aw a;

    ae() {
    }
}

