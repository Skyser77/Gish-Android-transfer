package com.gish.remaster;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import com.hardwire.blob.Main;
import com.gish.remaster.game.ad;

public class GameView extends View implements Runnable {
    private Main midlet;
    private ad gameCanvas;
    private boolean running = true;
    private Thread gameThread;
    private javax.microedition.lcdui.Graphics meGraphics;
    private Paint paint;

    public GameView(Context context) {
        super(context);
        setFocusable(true);
        setFocusableInTouchMode(true);
        paint = new Paint();
        
        // Start MIDlet
        midlet = new Main();
        midlet.startApp();
        
        javax.microedition.lcdui.Displayable disp = javax.microedition.lcdui.Display.getDisplay(midlet).getCurrent();
        if (disp instanceof ad) {
            gameCanvas = (ad) disp;
        }

        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (meGraphics == null) {
            meGraphics = new javax.microedition.lcdui.Graphics(canvas);
        } else {
            // update canvas reference
            // we can create a new Graphics wrapper per frame or update it
            meGraphics = new javax.microedition.lcdui.Graphics(canvas);
        }

        // Fill background black
        paint.setColor(0xFF000000);
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);

        if (gameCanvas != null) {
            try {
                gameCanvas.paint(meGraphics);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void run() {
        while (running) {
            try {
                // Call game tick / loop if present or repaint
                if (gameCanvas != null) {
                    // Trigger repaint
                    postInvalidate();
                }
                Thread.sleep(30);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        if (gameCanvas != null) {
            switch (event.getAction()) {
                private void push(int action) {}
                case MotionEvent.ACTION_DOWN:
                    // simulate pointer pressed or key fire/directions
                    break;
                case MotionEvent.ACTION_UP:
                    break;
            }
        }
        return true;
    }

    public void pause() {
        running = false;
        if (midlet != null) {
            midlet.pauseApp();
        }
    }

    public void resume() {
        running = true;
        if (gameThread == null || !gameThread.isAlive()) {
            gameThread = new Thread(this);
            gameThread.start();
        }
    }
}
