package com.gish.remaster;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;

public class GameView extends View implements Runnable {
    private javax.microedition.lcdui.Canvas gameCanvas;
    private MIDlet midlet;
    private Thread gameThread;
    private volatile boolean running = true;

    public GameView(Context context) {
        super(context);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    public void setGameCanvas(javax.microedition.lcdui.Canvas canvas) {
        this.gameCanvas = canvas;
    }

    public void setMIDlet(MIDlet midlet) {
        this.midlet = midlet;
    }

    public void start() {
        if (gameThread == null) {
            running = true;
            gameThread = new Thread(this);
            gameThread.start();
        }
    }

    public void stop() {
        running = false;
        if (gameThread != null) {
            try {
                gameThread.join();
            } catch (InterruptedException e) {
                // ignore
            }
            gameThread = null;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (gameCanvas != null) {
            javax.microedition.lcdui.Graphics g = new javax.microedition.lcdui.Graphics(canvas, getWidth(), getHeight());
            gameCanvas.paint(g);
        }
    }

    @Override
    public void run() {
        while (running) {
            try {
                if (gameCanvas != null) {
                    postInvalidate();
                }
                Thread.sleep(30);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        if (gameCanvas != null) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    gameCanvas.pointerPressed(x, y);
                    break;
                case MotionEvent.ACTION_UP:
                    gameCanvas.pointerReleased(x, y);
                    break;
                case MotionEvent.ACTION_MOVE:
                    gameCanvas.pointerDragged(x, y);
                    break;
            }
        }
        return true;
    }

    public void pause() {
        if (midlet != null) {
            midlet.notifyPaused();
        }
    }

    public void resume() {
        if (gameThread == null || !gameThread.isAlive()) {
            start();
        }
    }
}
