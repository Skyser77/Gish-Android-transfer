package javax.microedition.lcdui;

public class Display {
    private static Display instance = new Display();
    private Displayable current;

    public static Display getDisplay(javax.microedition.midlet.MIDlet m) {
        return instance;
    }

    public void setCurrent(Displayable next) {
        this.current = next;
    }

    public Displayable getCurrent() {
        return current;
    }
}
