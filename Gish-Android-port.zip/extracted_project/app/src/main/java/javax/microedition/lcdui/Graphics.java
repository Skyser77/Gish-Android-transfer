package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

public class Graphics {
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int HCENTER = 1;
    public static final int TOP = 16;
    public static final int BOTTOM = 32;
    public static final int VCENTER = 2;
    public static final int SOLID = 0;
    public static final int DOTTED = 1;

    private Canvas canvas;
    private Paint paint;
    private int color = 0xFF000000;

    public Graphics(Canvas canvas) {
        this.canvas = canvas;
        this.paint = new Paint();
        this.paint.setAntiAlias(false);
    }

    public void setColor(int rgb) {
        this.color = 0xFF000000 | rgb;
        this.paint.setColor(this.color);
        this.paint.setStyle(Paint.Style.FILL);
    }

    public void setColor(int red, int green, int blue) {
        this.color = 0xFF000000 | ((red & 0xFF) << 16) | ((green & 0xFF) << 8) | (blue & 0xFF);
        this.paint.setColor(this.color);
        this.paint.setStyle(Paint.Style.FILL);
    }

    public int getColor() {
        return this.color & 0x00FFFFFF;
    }

    public void fillRect(int x, int y, int width, int height) {
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRect(x, y, x + width, y + height, paint);
    }

    public void drawRect(int x, int y, int width, int height) {
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(x, y, x + width, y + height, paint);
    }

    public void drawLine(int x1, int y1, int x2, int y2) {
        canvas.drawLine(x1, y1, x2, y2, paint);
    }

    public void drawImage(Image img, int x, int y, int anchor) {
        if (img == null || img.bitmap == null) return;
        Bitmap bm = img.bitmap;
        int w = bm.getWidth();
        int h = bm.getHeight();
        
        if ((anchor & HCENTER) != 0) x -= w / 2;
        else if ((anchor & RIGHT) != 0) x -= w;
        
        if ((anchor & VCENTER) != 0) y -= h / 2;
        else if ((anchor & BOTTOM) != 0) y -= h;

        canvas.drawBitmap(bm, x, y, paint);
    }

    public void drawRegion(Image src, int x_src, int y_src, int width, int height, int transform, int x_dest, int y_dest, int anchor) {
        if (src == null || src.bitmap == null) return;
        // Simplified region drawing
        Bitmap sub = Bitmap.createBitmap(src.bitmap, x_src, y_src, width, height);
        drawImage(new Image(sub), x_dest, y_dest, anchor);
    }

    public void drawString(String str, int x, int y, int anchor) {
        if (str == null) return;
        paint.setStyle(Paint.Style.FILL);
        // handle anchor if needed
        canvas.drawText(str, x, y, paint);
    }

    public void setClip(int x, int y, int width, int height) {
        canvas.clipRect(x, y, x + width, y + height);
    }

    public int getClipX() { return 0; }
    public int getClipY() { return 0; }
    public int getClipWidth() { return canvas.getWidth(); }
    public int getClipHeight() { return canvas.getHeight(); }
}
