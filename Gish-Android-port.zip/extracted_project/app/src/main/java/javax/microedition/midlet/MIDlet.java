package javax.microedition.midlet;

public abstract class MIDlet {
    public MIDlet() {}

    public abstract void startApp();
    public abstract void pauseApp();
    public abstract void destroyApp(boolean unconditional);

    public void notifyDestroyed() {
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    public String getAppProperty(String key) {
        return null;
    }
}
