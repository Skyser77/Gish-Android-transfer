package javax.microedition.media;

import android.media.MediaPlayer;
import java.io.InputStream;

public class Player {
    private MediaPlayer mediaPlayer;
    private String locator;

    public Player(InputStream stream, String type) {
        // Android MediaPlayer handling
    }

    public Player(InputStream stream, String locator) {
        this.locator = locator;
    }

    public void realize() {}
    public void prefetch() {}
    public void start() {}
    public void stop() {}
    public void close() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
    public void setLoopCount(int count) {}
}
