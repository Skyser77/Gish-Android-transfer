package javax.microedition.media;

import java.io.InputStream;

public class Manager {
    public static Player createPlayer(InputStream stream, String type) throws java.io.IOException {
        return new Player(stream, type);
    }

    public static Player createPlayer(String locator) throws java.io.IOException {
        return new Player(null, locator);
    }

    public static void playTone(int note, int duration, int volume) {}
}
