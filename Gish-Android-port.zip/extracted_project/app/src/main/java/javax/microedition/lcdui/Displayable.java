package javax.microedition.lcdui;

public class Displayable {
    public void setCommandListener(CommandListener l) {}
}
