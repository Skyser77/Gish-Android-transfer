package javax.microedition.lcdui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import java.io.InputStream;

public class Image {
    public Bitmap bitmap;

    public Image(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public static Image createImage(int width, int height) {
        return new Image(Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888));
    }

    public static Image createImage(InputStream is) throws java.io.IOException {
        Bitmap bm = BitmapFactory.decodeStream(is);
        return new Image(bm);
    }

    public static Image createImage(String name) throws java.io.IOException {
        // Load from assets or resources
        InputStream is = com.gish.remaster.MainApplication.getContext().getAssets().open(name);
        Bitmap bm = BitmapFactory.decodeStream(is);
        is.close();
        return new Image(bm);
    }

    public static Image createImage(Image source, int x, int y, int width, int height, int transform) {
        if (source == null || source.bitmap == null) return null;
        Bitmap bm = Bitmap.createBitmap(source.bitmap, x, y, width, height);
        if (transform != 0) {
            Matrix matrix = new Matrix();
            if (transform == 2) { // Sprite.TRANS_MIRROR
                matrix.preScale(-1.0f, 1.0f);
            } else if (transform == 3) { // Sprite.TRANS_ROT180
                matrix.preRotate(180);
            } else if (transform == 5) { // Sprite.TRANS_MIRROR_ROT90
                matrix.preRotate(90);
                matrix.preScale(-1.0f, 1.0f);
            }
            try {
                Bitmap transformed = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), matrix, true);
                bm = transformed;
            } catch (Exception ignored) {}
        }
        return new Image(bm);
    }

    public static Image createImage(byte[] imageData, int imageOffset, int imageLength) {
        Bitmap bm = BitmapFactory.decodeByteArray(imageData, imageOffset, imageLength);
        return new Image(bm);
    }

    public Graphics getGraphics() {
        if (bitmap == null) return null;
        return new Graphics(new android.graphics.Canvas(bitmap));
    }

    public int getWidth() {
        return bitmap != null ? bitmap.getWidth() : 0;
    }

    public int getHeight() {
        return bitmap != null ? bitmap.getHeight() : 0;
    }
}
